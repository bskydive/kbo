({
  type: 'div',
  style: {
    justifyContent: 'center'
  },
  children: [{
    type: 'text',
    attr: {
      value: 'Yo'
    },
    style: {
      color: '#41B883',
      fontSize: '233px',
      textAlign: 'center'
    }
  }]
})
