module.exports = {
  extends: ['plugin:jest-playwright/recommended'],
};
