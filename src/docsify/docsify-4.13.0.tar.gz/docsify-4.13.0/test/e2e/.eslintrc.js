module.exports = {
  extends: ['plugin:playwright/playwright-test'],
};
